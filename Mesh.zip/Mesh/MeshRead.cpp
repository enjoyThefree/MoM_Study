#include"MeshRead.h"
#include<assert.h>

	MeshRead::MeshRead(string filename)
	{
		//�ж��ļ�����
		char dot = '.';
		int start = filename.find(dot);
		filetype = filename.substr(start + 1);

		this->filename = filename;
		ifstream infile(filename.c_str());
		if (!infile) {
			cout << "open nas file failure !" << endl;
			exit(0);
		}

		if (filetype == "nas") {
			string line;

			while (infile) {
				getline(infile, line);
				if (infile.fail()) break;

				stringstream sin(line);
				string type;
				sin >> type;
				if (type == "GRID*" || type == "grid*")
					verticesNum++;
				else if (type == "CTRIA3")
					elementNum++;
			}
			gridx.resize(verticesNum + 1);
			gridy.resize(verticesNum + 1);
			gridz.resize(verticesNum + 1);
			elementData.resize(elementNum + 1);
		}
		else if (filetype == "list") {
			string line, ignore;
			for (int i = 0; i < 2; i++) getline(infile, line);

			while (infile) {
				char ch;
				int verticeNum_One;
				int elementNum_One;
				getline(infile, line);
				if (infile.fail()) break;

				stringstream sin(line);
				ch = sin.peek();
				if (ch == '{') {
					getline(infile, line);
					stringstream sin(line);
					sin >> verticeNum_One >> elementNum_One >> ignore;
					verticesNum += verticeNum_One;
					elementNum += elementNum_One;
				}
			}
			gridx.resize(verticesNum + 1);
			gridy.resize(verticesNum + 1);
			gridz.resize(verticesNum + 1);
			elementData.resize(elementNum + 1);
		}

		infile.close();

	}

	void MeshRead::Read()
	{
		ifstream infile(filename.c_str());
		string line, ignore;
		int k = 0;
		if (filetype == "nas") {
			while (infile) {
				k++;
				string type;
				int index1, index2;
				double x , y, z;
				int p0, p1, p2;
				getline(infile, line);
				stringstream sin(line);
				sin >> type;
				if (type == "GRID*" || type == "*") {
					if (type == "GRID*") {
						sin >> index1 >> x >> y >> index2;
						assert(index1 == index2);
						gridx[index1] = x;
						gridy[index1] = y;
					}
					else if (type == "*") {
						sin >> index1 >> z;						
						gridz[index1] = z;
					}
				}
				else if (type == "CTRIA3") {
					vector<int> triangle;
					sin >> index1 >> ignore >> p0 >> p1 >> p2;
					triangle.push_back(p0);
					triangle.push_back(p1);
					triangle.push_back(p2);
					elementData[index1] = triangle;
				}
				// else if (type == "$")
				// 	continue;
				// else if (type == "ENDDATA")
				// 	Msg::Debug("EOF!");
				// else {
				// 	Msg::Warning("Unknow Input type:");
				// 	Msg::Warning("%s", line.c_str());
				// }
			}

		}
		else if (filetype == "list")
		{
			for (int i = 0; i < 2; i++) getline(infile, line);

			while (infile) {
				char ch;
				int verticesNum_One;
				int elementNum_One;
				getline(infile, line);
				stringstream sin(line);
				ch = sin.peek();
				if (ch == '{') {
					VerticeNumStart += VerticesNum_OneLayer;
					getline(infile, line);
					stringstream sin(line);
					sin >> verticesNum_One >> elementNum_One >> ignore;
					VerticesNum_OneLayer = verticesNum_One;
					ElementNum_OneLayer = elementNum_One;
					VerticeCoor_flag = true;
					ElementVerticeNum_flag = true;

					continue;
				}

				if (VerticeCoor_flag == true)
				{
					verticeCount++;
					VerticeNumbering++;
					double x, y, z;
					sin >> x >> y >> z;
					gridx[VerticeNumbering] = x;
					gridy[VerticeNumbering] = y;
					gridz[VerticeNumbering] = z;

					if (verticeCount >= VerticesNum_OneLayer)
						VerticeCoor_flag = false;
				}
				else if (ElementVerticeNum_flag == true)
				{
					elementCount++;
					ElementNumbering++;
					int number;
					int p0, p1, p2, p3;
					sin >> number;
					if (number == 3) {
						vector<int> triangle;
						sin >> p0 >> p1 >> p2 >> ignore >> ignore >> ignore;
						p0 += VerticeNumStart + 1;
						p1 += VerticeNumStart + 1;
						p2 += VerticeNumStart + 1;
						triangle.push_back(p0);
						triangle.push_back(p1);
						triangle.push_back(p2);
						elementData.push_back(triangle);
					}
					else if (number == 4) {
						vector<int> quad;
						sin >> p0 >> p1 >> p2 >> p3 >> ignore >> ignore >> ignore;
						p0 += VerticeNumStart + 1;
						p1 += VerticeNumStart + 1;
						p2 += VerticeNumStart + 1;
						p3 += VerticeNumStart + 1;
						quad.push_back(p0);
						quad.push_back(p1);
						quad.push_back(p2);
						quad.push_back(p3);
						elementData.push_back(quad);
					}

					if (elementCount > ElementNum_OneLayer)
						ElementVerticeNum_flag = false;

				}

			}

		}

		infile.close();
	}

	void MeshRead::store() {
		ofstream outf1("Coordinate.txt");
		ofstream outf2("element.txt");
		if (!outf1.is_open()) {
			cout << "open grid file failure!";
			exit(0);
		}
		if (!outf2.is_open()) {
			cout << "open element file failure!";
			exit(0);
		}
		for (int i = 1; i < gridx.size(); i++) {
			outf1 << gridx[i] << " " << gridy[i] << " " << gridz[i] << endl;
		}

		for (int i = 1; i < elementData.size(); i++) {
			if (elementData[i].size() == 3)
				outf2 << elementData[i][0] << " " << elementData[i][1] << " " << elementData[i][2] << endl;
			if (elementData[i].size() == 4)
				outf2 << elementData[i][0] << " " << elementData[i][1] << " " << elementData[i][2] << " " << elementData[i][3] << endl;
		}

	}

