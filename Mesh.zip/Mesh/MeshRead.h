#pragma once
#ifndef MeshRead_H
#define MeshRead_H
#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<sstream>
#include<armadillo>

using namespace std;
using namespace arma;

	class MeshRead
	{
	public:
		MeshRead(string filename);
		/*void Read(const vector<FLayer>& metal_layer, const vector<FLayer>& dielectric_layer,
			vector<Element>& element_list);*/

		void Read();
		void store();
	private:
		string filename;
		string filetype;
		int verticesNum = 0;
		int elementNum = 0;

		int VerticesNum_OneLayer = 0;
		int ElementNum_OneLayer = 0;
		bool VerticeCoor_flag;         //�Ƿ��ȡ��������
		bool ElementVerticeNum_flag;   //�Ƿ��ȡ element ������
		int VerticeNumStart = 0;
		int VerticeNumbering = 0;
		int ElementNumbering = 0;
		int verticeCount;
		int elementCount;

	private:
		vector<double> gridx, gridy, gridz;
		//�����ı���
		vector<vector<int>> elementData;

	private:
		/*Element GenerateElement(int index, const vector<FLayer>& metal_layer,
			const vector<FLayer>& dielectric_layer);*/
	};

#endif // MeshRead_H