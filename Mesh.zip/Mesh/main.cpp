#include<iostream>
#include<fstream>
#include<armadillo>
#include"ReadData.h"
#include "MeshRead.h"
#define MeshRead_H

using namespace std;
using namespace arma;


    int main()
    {
        string Filename = "mesh.nas";
        //Mesh
        MeshRead mesh(Filename);
        mesh.Read();
        mesh.store();
        cout << "ok" << endl;

        return 0;

    }


